#include <iostream>
#include <cstring>
#include <ctime>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>

using namespace std;

#define MAXLINE 4096
#define SERV_PORT 12345
#define LISTENQ 8

void handle_client(int connfd) {
    char buff[MAXLINE];
    time_t ticks = time(nullptr);
    snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
    write(connfd, buff, strlen(buff));
    close(connfd);
}

int main() {
    int listenfd, connfd;
    pid_t childpid;
    socklen_t clilen;
    struct sockaddr_in cliaddr, servaddr;

    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        cerr << "Error: Problem in creating the socket" << endl;
        exit(2);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(SERV_PORT);

    if (bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Error: Problem in binding the socket" << endl;
        exit(3);
    }

    if (listen(listenfd, LISTENQ) < 0) {
        cerr << "Error: Problem in listening on the socket" << endl;
        exit(4);
    }

    cout << "Server running...waiting for connections." << endl;

    for (;;) {
        clilen = sizeof(cliaddr);

        if ((connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &clilen)) < 0) {
            cerr << "Error: Problem in accepting the connection" << endl;
            continue;
        }

        cout << "Received request..." << endl;

        if ((childpid = fork()) == 0) {
            cout << "Child created to handle client requests." << endl;
            close(listenfd);
            handle_client(connfd);
            exit(0);
        }

        close(connfd);
    }

    return 0;
}

