#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLINE 1024
#define LISTENQ 1024

int main() {
    int listenfd, connfd;
    socklen_t len;
    struct sockaddr_in servaddr, cliaddr;
    char buff[MAXLINE];
    ssize_t n;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) {
        perror("Socket error");
        exit(1);
    }

    std::memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(12345);  

 
    if (bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind error");
        exit(1);
    }

    if (listen(listenfd, LISTENQ) < 0) {
        perror("Listen error");
        exit(1);
    }

    std::cout << "Server is running and waiting for connections...\n";

    for (;;) {
        len = sizeof(cliaddr);

        connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &len);
        if (connfd < 0) {
            perror("Accept error");
            exit(1);
        }

        std::cout << "Connection from " 
                  << inet_ntoa(cliaddr.sin_addr) 
                  << ", port " << ntohs(cliaddr.sin_port) << "\n";

        while ((n = read(connfd, buff, MAXLINE)) > 0) {
            write(connfd, buff, n);  
        }

        if (n == 0) {
            std::cout << "Client disconnected.\n";
        } else {
            perror("Read error");
        }

        close(connfd);
    }

    return 0;
}

