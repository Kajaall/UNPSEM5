#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAXLINE 4096
#define SERV_PORT 12345

using namespace std;

int main(int argc, char **argv) {
    int sockfd;
    struct sockaddr_in servaddr;
    char sendline[MAXLINE], recvline[MAXLINE];

    if (argc != 2) {
        cerr << "Usage: UDPClient <Server IP>" << endl;
        exit(1);
    }

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        cerr << "Socket creation failed" << endl;
        exit(1);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

    sendto(sockfd, sendline, 0, 0, (struct sockaddr*)&servaddr, sizeof(servaddr));

    socklen_t len = sizeof(servaddr);
    int n = recvfrom(sockfd, recvline, MAXLINE, 0, (struct sockaddr*)&servaddr, &len);
    if (n < 0) {
        cerr << "recvfrom failed" << endl;
        exit(1);
    }

    cout << "Received time from server: " << recvline << endl;

    close(sockfd);
    return 0;
}

