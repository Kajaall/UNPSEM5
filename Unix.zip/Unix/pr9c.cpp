#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <chrono>

#define PORT 12345
#define BUFFER_SIZE 64

int main() {
    int client_fd;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in server_addr;

    // Create UDP socket
    client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_fd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Connect to the server
    if (connect(client_fd, (const struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(client_fd);
        return 1;
    }

    // Message to send (clearing the buffer)
    memset(buffer, static_cast<unsigned char>('A'), BUFFER_SIZE);

    for (int i = 0; i < 3; ++i) {
        // Record start time
        auto start_time = std::chrono::high_resolution_clock::now();

        // Send message
        if (send(client_fd, buffer, BUFFER_SIZE, 0) < 0) {
            perror("Send failed");
            continue;
        }

        // Receive response
        int n = recv(client_fd, buffer, BUFFER_SIZE, 0);
        if (n < 0) {
            perror("Receive failed");
            continue;
        }

        // Record end time and calculate elapsed time
        auto end_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_time = end_time - start_time;

        std::cout << "Round " << (i + 1) << ": Received " << n 
                  << " bytes in " << elapsed_time.count() << " seconds" << std::endl;
    }

    close(client_fd);
    return 0;
}

