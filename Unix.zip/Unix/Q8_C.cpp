#include <iostream>
#include <fstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

using namespace std;

#define PORT 8080
#define MAX_BUFFER_SIZE 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char filename[MAX_BUFFER_SIZE];
    char buffer[MAX_BUFFER_SIZE];

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        return -1;
    }

    cout << "Enter filename to request from server: ";
    cin.getline(filename, MAX_BUFFER_SIZE);

    // Send the filename to the server
    if (send(sock, filename, strlen(filename), 0) < 0) {
        perror("Send filename failed");
        return -1;
    }

    // Receive the file or error message from the server
    ofstream outfile(filename, ios::binary);  // Save the file with the same name as requested
    int recv_len;
    bool is_error = false;

    while ((recv_len = recv(sock, buffer, MAX_BUFFER_SIZE, 0)) > 0) {
        if (recv_len < MAX_BUFFER_SIZE) {
            buffer[recv_len] = '\0';  // Null-terminate the string
            if (strncmp(buffer, "Error:", 6) == 0) {
                is_error = true;
                break;
            }
        }
        outfile.write(buffer, recv_len);
    }

    if (is_error) {
        cout << "Server response: " << buffer << endl;
    } else {
        cout << "File '" << filename << "' received successfully." << endl;
    }

    // Close the file and socket
    outfile.close();
    close(sock);

    return 0;
}
