#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLINE 4096
#define SERV_PORT 12345

using namespace std;

void str_echo(int connfd) {
    char buf[MAXLINE];
    int n;
    
    while (true) {
        n = recv(connfd, buf, MAXLINE, 0);
        if (n < 0) {
            cerr << "Error in receiving data" << endl;
            return;
        }
        buf[n] = '\0';
        cout << "Server received: " << buf << endl;

        if (strcmp(buf, "bye") == 0) {
            cout << "Server ends conversation." << endl;
            break;
        }

        cout << "Server, enter message to send to client: ";
        cin.getline(buf, MAXLINE);
        
        send(connfd, buf, strlen(buf), 0);
        
        if (strcmp(buf, "bye") == 0) {
            cout << "Server ends conversation." << endl;
            break;
        }
    }
}

int main() {
    int listenfd, connfd;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t clilen;

    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        cerr << "Socket creation failed" << endl;
        return 1;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(SERV_PORT);

    if (bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Bind failed" << endl;
        return 1;
    }

    if (listen(listenfd, 5) < 0) {
        cerr << "Listen failed" << endl;
        return 1;
    }

    cout << "Server is running... waiting for connections." << endl;

    while (true) {
        clilen = sizeof(cliaddr);
        connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &clilen);
        if (connfd < 0) {
            cerr << "Accept failed" << endl;
            continue;
        }

        cout << "Connection established with client." << endl;

        str_echo(connfd);

        close(connfd);
    }

    close(listenfd);
    return 0;
}

