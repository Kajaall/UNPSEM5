#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLINE 4096
#define SERV_PORT 12345

using namespace std;

int main(int argc, char **argv) {

    struct sockaddr_in servaddr;
    char buf[MAXLINE];


    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        cerr << "Socket creation failed" << endl;
        return 1;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Connection failed" << endl;
        return 1;
    }

    cout << "Connected to the server." << endl;

    while (true) {
        cout << "Client, enter message to send to server: ";
        cin.getline(buf, MAXLINE);

        send(sockfd, buf, strlen(buf), 0);

        if (strcmp(buf, "bye") == 0) {
            cout << "Client ends conversation." << endl;
            break;
        }

        int n = recv(sockfd, buf, MAXLINE, 0);
        if (n <= 0) {
            cerr << "Error in receiving message from server" << endl;
            break;
        }
        buf[n] = '\0';

        cout << "Client received: " << buf << endl;

        if (strcmp(buf, "bye") == 0) {
            cout << "Server ends conversation." << endl;
            break;
        }
    }

    close(sockfd);
    return 0;
}

