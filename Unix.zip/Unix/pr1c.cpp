#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLINE 1024

int main() {
    int sockfd;
    struct sockaddr_in servaddr;
    char buff[MAXLINE];
    ssize_t n;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket error");
        exit(1);
    }

    std::memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(12345);  

    if (inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr) <= 0) {
        perror("Inet_pton error");
        exit(1);
    }

    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Connect error");
        exit(1);
    }

    std::cout << "Connected to the server. Type 'exit' to quit.\n";

    while (true) {
        std::cout << "Enter message: ";
        if (!std::cin.getline(buff, MAXLINE)) {
            break;
        }

        if (strncmp(buff, "exit", 4) == 0) {
            break;
        }

        write(sockfd, buff, strlen(buff));

        n = read(sockfd, buff, MAXLINE);
        if (n > 0) {
            std::cout << "Echo from server: " << std::string(buff, n) << "\n";
        } else {
            perror("Read error");
            break;
        }
    }

    close(sockfd);
    return 0;
}

