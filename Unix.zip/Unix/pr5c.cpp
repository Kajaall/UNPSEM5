#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAXLINE 4096
#define SERV_PORT 9877

int main(int argc, char **argv) {
    int sockfd;
    struct sockaddr_in servaddr;
    char sendline[MAXLINE], recvline[MAXLINE];

    if (argc != 2) {
        std::cerr << "Usage: udpcli <Server-IP>" << std::endl;
        exit(1);
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        std::cerr << "Socket error" << std::endl;
        exit(1);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

    while (true) {
        std::cout << "Enter message to send: ";
        std::cin.getline(sendline, MAXLINE);

        sendto(sockfd, sendline, strlen(sendline), 0, (struct sockaddr *)&servaddr, sizeof(servaddr));

        ssize_t n = recvfrom(sockfd, recvline, MAXLINE, 0, NULL, NULL);
        if (n < 0) {
            std::cerr << "Recvfrom error" << std::endl;
            exit(1);
        }

        recvline[n] = '\0';
        std::cout << "Received from server: " << recvline << std::endl;
    }

    return 0;
}

