#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

#define MAXLINE 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: ./tcpcli <Server-IP>" << endl;
        return 1;
    }

    int sockfd;
    struct sockaddr_in servaddr;
    char buff[MAXLINE];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(12345);  // Daytime server port

    if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0) {
        cerr << "Invalid address or address not supported" << endl;
        return 1;
    }

    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Connection failed" << endl;
        return 1;
    }

    int n = read(sockfd, buff, sizeof(buff) - 1);
    if (n > 0) {
        buff[n] = '\0';
        cout << "Server time: " << buff << endl;
    } else {
        cerr << "Failed to read from server" << endl;
    }

    close(sockfd);
    return 0;
}

