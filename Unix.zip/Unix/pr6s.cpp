#include <iostream>
#include <cstring>
#include <ctime>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAXLINE 4096
#define SERV_PORT 12345

using namespace std;

int main() {
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t clilen;
    char buffer[MAXLINE];
    time_t ticks;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        cerr << "Socket creation failed" << endl;
        exit(1);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(SERV_PORT);

    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Bind failed" << endl;
        exit(1);
    }

    cout << "Server running...waiting for requests." << endl;

    while (true) {
        clilen = sizeof(cliaddr);
        int n = recvfrom(sockfd, buffer, MAXLINE, 0, (struct sockaddr*)&cliaddr, &clilen);
        if (n < 0) {
            cerr << "recvfrom failed" << endl;
            continue;
        }

        ticks = time(nullptr);
        snprintf(buffer, sizeof(buffer), "%.24s\r\n", ctime(&ticks));

        sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&cliaddr, clilen);
    }

    close(sockfd);
    return 0;
}

