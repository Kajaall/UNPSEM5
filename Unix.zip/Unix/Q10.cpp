#include <iostream>
#include <cstring>
#include <vector>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <cstdlib>
#include <stdio.h>

using namespace std;

void displayHostName() {
    char hostname[1024];
    if (gethostname(hostname, sizeof(hostname)) == 0) {
        cout << "Host Name: " << hostname << endl;
    } else {
        perror("gethostname failed");
    }
}

void displayIPAddresses() {
    struct ifaddrs *interfaces = nullptr, *ifa = nullptr;
    void *tmpAddrPtr = nullptr;

    if (getifaddrs(&interfaces) == 0) {
        for (ifa = interfaces; ifa != nullptr; ifa = ifa->ifa_next) {
            if (ifa->ifa_addr->sa_family == AF_INET) {  // IPv4
                tmpAddrPtr = &((struct sockaddr_in*)ifa->ifa_addr)->sin_addr;
                char addressBuffer[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
                cout << "IP Address: " << addressBuffer << " (Interface: " << ifa->ifa_name << ")" << endl;
            }
        }
        freeifaddrs(interfaces);
    } else {
        perror("getifaddrs failed");
    }
}

bool isServiceRunning(const string &serviceName) {
    string command = "netstat -tuln | grep " + serviceName;
    int ret = system(command.c_str());
    return (ret == 0);  // Return true if service is found
}

void checkServices() {
    cout << "Checking if FTP service is running..." << endl;
    if (isServiceRunning("ftp")) {
        cout << "FTP service is running." << endl;
    } else {
        cout << "FTP service is NOT running." << endl;
    }

    cout << "Checking if HTTP service is running..." << endl;
    if (isServiceRunning("http")) {
        cout << "HTTP service is running." << endl;
    } else {
        cout << "HTTP service is NOT running." << endl;
    }
}

void displayServiceNameByPort(int port) {
    struct servent *service = getservbyport(htons(port), NULL);
    if (service != NULL) {
        cout << "Service running on port " << port << " is " << service->s_name << endl;
    } else {
        cout << "No service found running on port " << port << endl;
    }
}

int main() {
    // Display host name
    displayHostName();

    // Display IP addresses
    displayIPAddresses();

    // Check for FTP and HTTP services
    checkServices();

    // Ask for port number and display the service running on that port
    int port;
    cout << "Enter a port number to check the service: ";
    cin >> port;
    displayServiceNameByPort(port);

    return 0;
}
