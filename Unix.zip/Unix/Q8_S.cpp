#include <iostream>
#include <fstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;

#define PORT 8080
#define MAX_BUFFER_SIZE 1024

void handleClient(int client_fd) {
    char filename[MAX_BUFFER_SIZE];
    char buffer[MAX_BUFFER_SIZE];
    int recv_len;

    // Receive the filename from the client
    recv_len = recv(client_fd, filename, sizeof(filename), 0);
    if (recv_len <= 0) {
        perror("Receive filename failed");
        return;
    }
    filename[recv_len] = '\0';  // Null-terminate the filename string
    cout << "Client requested file: " << filename << endl;

    // Open the requested file
    ifstream file(filename, ios::binary);
    if (!file.is_open()) {
        // File not found, send error message to client
        const char *error_message = "Error: File not found!";
        send(client_fd, error_message, strlen(error_message), 0);
    } else {
        // File found, send the file to the client
        while (!file.eof()) {
            file.read(buffer, MAX_BUFFER_SIZE);
            send(client_fd, buffer, file.gcount(), 0);
        }
        cout << "File sent to client." << endl;
    }

    // Close the file and the client socket
    file.close();
    close(client_fd);
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        return -1;
    }

    // Set server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        return -1;
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        return -1;
    }

    cout << "Server listening on port " << PORT << endl;

    // Accept incoming client connections
    while (true) {
        if ((client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Accept failed");
            continue;
        }

        cout << "Client connected." << endl;

        // Fork a new process to handle the client
        pid_t pid = fork();
        if (pid == 0) {
            // Child process
            close(server_fd);  // Close the server socket in the child process
            handleClient(client_fd);
            exit(0);  // Exit the child process after handling the client
        } else if (pid > 0) {
            // Parent process continues to accept new connections
            close(client_fd);  // Close the client socket in the parent process
        } else {
            perror("Fork failed");
            continue;
        }
    }

    // Close the server socket
    close(server_fd);

    return 0;
}
