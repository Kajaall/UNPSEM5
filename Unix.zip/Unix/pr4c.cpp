#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

#define MAXLINE 4096
#define SERV_PORT 12345

int main(int argc, char** argv) {
    int sockfd;
    struct sockaddr_in servaddr;
    char recvline[MAXLINE];

    if (argc != 2) {
        cerr << "Usage: TCPClient <IP address of the server>" << endl;
        exit(1);
    }

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        cerr << "Error: Problem in creating the socket" << endl;
        exit(2);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(SERV_PORT);

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Error: Problem in connecting to the server" << endl;
        exit(3);
    }

    if (recv(sockfd, recvline, MAXLINE, 0) == 0) {
        cerr << "Error: Server terminated prematurely" << endl;
        exit(4);
    }

    cout << "Received from the server: " << recvline << endl;

    close(sockfd);
    return 0;
}

