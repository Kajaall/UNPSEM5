#include <iostream>
#include <cstring>      
#include <sys/types.h>  
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <unistd.h>     
#include <arpa/inet.h>

using namespace std;

#define MAXLINE 4096  
#define SERV_PORT 3000 
#define LISTENQ 8     

int main(int argc, char** argv) {
    int listenfd, connfd, n;
    pid_t childpid;
    socklen_t clilen;
    char buf[MAXLINE];
    struct sockaddr_in cliaddr, servaddr;

    
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        cerr << "Error: Problem in creating the socket" << endl;
        exit(2);
    }

    
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(SERV_PORT);

    
    if (bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        cerr << "Error: Problem in binding the socket" << endl;
        exit(3);
    }

 
    if (listen(listenfd, LISTENQ) < 0) {
        cerr << "Error: Problem in listening on the socket" << endl;
        exit(4);
    }

    cout << "Server running...waiting for connections." << endl;

  
    for (;;) {
        clilen = sizeof(cliaddr);

       
        if ((connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &clilen)) < 0) {
            cerr << "Error: Problem in accepting the connection" << endl;
            continue;
        }

        cout << "Received request..." << endl;

        
        if ((childpid = fork()) == 0) {
            cout << "Child created to handle client requests." << endl;

            
            close(listenfd);

            
            while ((n = recv(connfd, buf, MAXLINE, 0)) > 0) {
                cout << "String received from and sent to the client: " << buf << endl;
                send(connfd, buf, n, 0);
                memset(buf, 0, MAXLINE); 
            }

            if (n < 0) {
                cerr << "Error: Read error" << endl;
            }

            close(connfd); 
            exit(0);       
        }

       
        close(connfd);
    }

    return 0;
}
